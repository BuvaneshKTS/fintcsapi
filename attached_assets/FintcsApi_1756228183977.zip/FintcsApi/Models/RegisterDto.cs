namespace FintcsApi.Models
{
    public class RegisterDto
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

        // Extra fields (will be stored in Details JSON)
        public string EDPNo { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string AddressO { get; set; } = string.Empty; // Office Address
        public string AddressR { get; set; } = string.Empty; // Residential Address
        public string Designation { get; set; } = string.Empty;
        public string PhoneO { get; set; } = string.Empty;
        public string PhoneR { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        
        // Optional role (default = user)
        public string Role { get; set; } = "user";
    }
}
