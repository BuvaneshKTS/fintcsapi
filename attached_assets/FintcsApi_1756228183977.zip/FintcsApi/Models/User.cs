namespace FintcsApi.Models
{
    public class User
    {
        public int Id { get; set; }

        // Main login fields
        public string Username { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;

        // JSON stored as string for other details
        public string? Details { get; set; } 
    }

    // Helper class to represent Details as object
    public class UserDetails
    {
        public string EDPNo { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string AddressOffice { get; set; } = string.Empty;
        public string AddressResidential { get; set; } = string.Empty;
        public string Designation { get; set; } = string.Empty;
        public string PhoneOffice { get; set; } = string.Empty;
        public string PhoneResidential { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
